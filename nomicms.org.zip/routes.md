# Какие маршруты доступны в данный момент на сайте

> http://l9288528.beget.tech

## Маршруты модуля чат
- /chat
- /chat/reply/Tosyk
- /chat/1/del

## Маршруты главного модуля
- /
- /pages
- /pages/bbcode
- /pages/smiles
- /error
- /error/404

## Маршруты модуля новости
- /news
- /news/add
- /news/id (id новости)
- /news/id/edit (id новости, и edit, либо del)

## Маршруты модуля тем оформлений
- /user/themes

## Маршруты модуля пользователь
- /user
- /user/id1
- /user/settings
- /signup
- /entry
- /user/leave
