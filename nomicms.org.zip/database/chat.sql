--
-- Структура таблицы `chat`
--

DROP TABLE IF EXISTS `chat`;
CREATE TABLE IF NOT EXISTS `chat` (
    `uid` int(10) unsigned NOT NULL,
    `user_uid` int(10) NOT NULL,
    `message` text NOT NULL,
    `time` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_general_ci AUTO_INCREMENT=2 COMMENT='Мини-чат';

--
-- Индексы таблицы `chat`
--

ALTER TABLE `chat`
  ADD PRIMARY KEY (`uid`),
  ADD KEY `user_uid` (`user_uid`);

--
-- Дамп данных таблицы `chat`
--

INSERT INTO `chat` (`uid`, `user_uid`, `message`, `time`) VALUES
(1, 1, 'Вас приветствует NomiCMS v3.0', 1613296024);
COMMIT;
