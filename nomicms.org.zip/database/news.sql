--
-- Структура таблицы `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
    `uid` int(10) unsigned NOT NULL,
    `user_uid` int(10) NOT NULL,
    `message` text NOT NULL,
    `time` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_general_ci AUTO_INCREMENT=2 COMMENT='Мини-чат';

--
-- Индексы таблицы `news`
--

ALTER TABLE `news`
  ADD PRIMARY KEY (`uid`),
  ADD KEY `user_uid` (`user_uid`);

--
-- Дамп данных таблицы `news`
--

INSERT INTO `news` (`uid`, `user_uid`, `message`, `time`) VALUES
(1, 1, 'Nomicms v3.0', 1613296024);
COMMIT;
