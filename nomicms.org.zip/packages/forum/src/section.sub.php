<?php
/**
 * NomiCMS - Content Management System
 *
 * @author Tosyk, Photon
 * @package nomicms/NomiCMS
 * @link   http://nomicms.ru
 */

echo '<br />Раздел ' . $forumId;
echo '<br />Подраздел ' . $forumSubId;
