<?php declare(strict_types=1);
/**
 * NomiCMS - Content Management System
 *
 * @author Tosyk, Photon
 * @package nomicms/NomiCMS
 * @link   http://nomicms.ru
 */

namespace Packages\Main\Component;

/**
 * Установщик модуля main
 */
class MainSetur
{
    public function open()
    {
        return 'MainSetur загружен';
    }
}
