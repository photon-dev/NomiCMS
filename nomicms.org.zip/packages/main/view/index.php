    <div class="main">
        Привет <b><?php echo $welcome ?></b>, шаблон packages/view/index загружен<br />
    </div>
