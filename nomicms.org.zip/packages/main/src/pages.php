<?php
/**
 * NomiCMS - Content Management System
 *
 * @author Tosyk, Photon
 * @package nomicms/NomiCMS
 * @link   http://nomicms.ru
 */

// Загрузить вид

//$main = $container->get('config')->get('route');
//$db = $container->get('db');

//$view::set('test', 'аххахаха');

return 'Страницы';
