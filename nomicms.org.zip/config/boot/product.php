<?php
/**
 * NomiCMS - Content Management System
 *
 * @author Tosyk,  Photon
 * @package nomicms/NomiCMS
 * @link   http://nomicms.ru
 */

error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT);
ini_set('display_errors', 'Off');
