    <div class="footer">
        <a href="/" title="Онлайн">Онлайн: 1 </a> | 0<br />
        Память: <?php echo $memory; ?> кб<br />
        Генерация: <?php echo $timing; ?> сек
    </div>
