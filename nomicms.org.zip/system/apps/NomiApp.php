<?php
/**
 * NomiCMS - Content Management System
 *
 * @author Tosyk, Photon
 * @package nomicms/NomiCMS
 * @link   http://nomicms.ru
 */

namespace System\App;

// Использовать
use System\Container\ContainerInterface;
use System\Router\RouterInterface;
use System\App\SourceFile;

/**
 * Класс NomiApp
 */
class NomiApp extends Source
{
    // Контейнер зависимостей
    protected $container;

    // Маршрутизатор
    protected $router;

    // Маршрут
    protected $route = [];

    // Страница не найдена
    public const FOUND = true;
    // Страница не найдена
    public const NOT_FOUND = false;

    // Конструктор
    public function __construct(ContainerInterface $container, RouterInterface $router)
    {
        // Установить контейнер
        $this->container = $container;

        // Установить маршрутизатор
        $this->router = $router;

        // Получить маршрут
        $this->route = $this->router->getRoute();
    }

    // Получить параметры
    public function getParams()
    {
        return $this->route['params'];
    }

    // Запустить
    public function run()
    {
        // Если маршрут найден, сообщить об этом
        if ($this->router->getFound()) {
            return true;
        }

        // Показать ошибку
        return false;
    }

    // Полулучить информацию о маршруте
    public function getRoute()
    {
        return $this->route;
    }

    // Получить ошибку
    public function notFound(string $error = 'Страница не найдена')
    {
        return error($error);
    }
}
