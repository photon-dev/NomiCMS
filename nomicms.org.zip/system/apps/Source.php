<?php
/**
 * NomiCMS - Content Management System
 *
 * @author Tosyk, Photon
 * @package nomicms/NomiCMS
 * @link   http://nomicms.ru
 */

namespace System\App;

// Использовать
use System\Container\ContainerInterface;
use System\Router\RouterInterface;

/**
 * Класс Package
 */
class Source
{
    // Существует ли пакет
    public function hasPackage()
    {
        return is_dir(PACKS . $this->getPathPackage());
    }

    // Существует ли исходный файл
    public function hasSource()
    {
        return file_exists(PACKS . $this->getPathSource());
    }

    // Получить путь пакету
    public function getPathPackage()
    {
        return $this->route['package'] . '/';
    }

    // Получить путь к исходному файлу
    public function getPathSource()
    {
        return $this->route['package'] . '/src/' . $this->route['src'] . '.php';
    }
}
