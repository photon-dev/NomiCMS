<?php declare(strict_types=1);
/**
 * NomiCMS - Content Management System
 *
 * @author Tosyk, Photon
 * @package nomicms/NomiCMS
 * @link   http://nomicms.ru
 */

namespace System\Cache;

// Подключение бибилиотек
use System\Cache\CacheInterface;
use System\Cache\Exception\CacheNotFound;

/**
 * Класс кеширования
 */
class Cache implements CacheInterface
{
    // Путь к системной папки кэширования
    protected static $path = '';

    // Формат хранения данных
    const EXT_CACHE = '.json';

    public static function open(string $file)
    {
        if (self::has($file) === false) {
            throw new CacheNotFound("Файл {$file} не найден");
        }
    }

    public static function create(string $file, array $data = [])
    {
        if (self::has($file)) {
            throw new CacheNotFound("Кэш {$file} уже создан");
        }

        // Получить путь к файлу
        $path = self::getFilePath($file);

        file_put_contents(
            $path,
            json_encode($data, JSON_UNESCAPED_UNICODE),
            LOCK_EX
        );

        chmod($path, 0644);
        return true;
    }

    // Проверить существование файла
    public static function has(string $file)
    {
        if (file_exists(self::getFilePath($file))) {
            return true;
        }

        return false;
    }

    // Получить путь к файлу
    protected static function getFilePath(string $file)
    {
        return self::$path . $file . self::EXT_CACHE;
    }

    // Получить путь к папке
    public static function getPath(string $file)
    {
        return self::$path;
    }

    // Установить папку, где храняться кэш файлы
    public static function setPath(string $path)
    {
        // Проверить путь
        if (empty(self::$path) === false || self::$path == $path) {
            throw new CacheNotFound('Путь кэширования повторно установлен быть не может');
        }

        // Установить путь
        self::$path = $path;
        return true;
    }
}
